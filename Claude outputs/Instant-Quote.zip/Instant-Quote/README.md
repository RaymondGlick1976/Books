# Homestead Cabinet Design — Instant Quote

Card-by-card quote wizard for **instant-quote.homesteadcabinetdesign.com**.
Standalone Netlify site (like the visualizer), plain HTML/CSS/JS, no build step.
Answers are saved to the **HCD Books** Supabase project after every step; pricing is read from the same project.

- Netlify project: `hcd-instant-quote` → https://app.netlify.com/projects/hcd-instant-quote
- Supabase project: HCD Books (`byozvlgtbwiohyrfvxii`)
- Tables: `instant_quotes` (one row per visitor session), `instant_quote_pricing` (editable price rules)

## Folder layout
```
Instant-Quote/
├── public/
│   ├── index.html          # page shell: top bar, hero + "how it works", wizard, footer (inline CSS, site tokens)
│   └── js/
│       ├── config.js       # public config (api base, booking URL, step count)
│       ├── cards.js        # THE CARDS — add one object per question here
│       └── quote.js        # card engine: render, state, back/next, autosave
├── netlify/functions/
│   └── save-quote.js       # POST /api/save-quote → upsert instant_quotes
├── database/
│   └── 001-instant-quote-tables.sql   # already applied to HCD Books (reference copy)
├── netlify.toml
└── package.json
```

## First-time setup (one time, Raymond)
1. Copy this folder to `C:\_Websites\Instant-Quote`, `git init`, push to a new GitHub repo.
2. In Netlify → `hcd-instant-quote` → **Site configuration → Build & deploy → Link repository** → pick the repo
   (build command: none, publish dir `public`, functions `netlify/functions` — all read from `netlify.toml`).
3. **Environment variables** (Site configuration → Environment variables):
   - `SUPABASE_URL` = `https://byozvlgtbwiohyrfvxii.supabase.co` ✅ already set
   - `SUPABASE_SERVICE_ROLE_KEY` = copy the value from the **hcdbooks** site's env vars (secret) — **you must add this**
4. **Domain**: Domain management → Add domain → `instant-quote.homesteadcabinetdesign.com`.
   Then in your DNS (same place `visualizer` points), add a CNAME: `instant-quote` → `hcd-instant-quote.netlify.app`.
5. Push → deploy. Open the site, pick a service, then check HCD Books Supabase → `instant_quotes` for the row.

## How the wizard works
- `IQ_CARDS` (cards.js) is an ordered list. Each card has `id`, `question`, `type` (`single` tiles or `select` dropdown),
  `options`, and an optional `next(answers)` function to branch (e.g. painting → ask about wood species; refacing → door style).
- Every answer is stored in `sessionStorage` under `hcd_instant_quote_v1` and POSTed to `/api/save-quote`
  with a browser-generated `quote_id` (UUID). The function upserts on that id, so one visitor = one row that fills in over time.
- `IQ_CONFIG.totalSteps` drives the progress bar — bump it as cards are added.
- When the engine runs out of cards it shows the "under construction" card with a Book-a-consultation button.

## Card roadmap (build one at a time)
| # | id | Question | Notes |
|---|----|----------|-------|
| 1 | `service` | What would you like done? | ✅ built — 7 tiles |
| 2 | `kitchen_size` | How big is the kitchen? (small / medium / large / XL, with door+drawer count hints) | drives per-opening scaling |
| 3 | per-service | Painting: wood species (oak surcharge), two-tone? · Refacing: door style / material · Remodel: partial vs full · Storage: which add-ons (multi-select) | branch via `next()` |
| 4 | `condition` | Current cabinet condition / age | adjusts range or flags "needs a look" |
| 5 | `timeline` + `location` | When, and what town/zip | service-area check (MA/CT) |
| 6 | `contact` | Name, email, phone → **show estimate** | sets status `priced`/`submitted`, emails Raymond via Resend, creates HCD Books lead/job |

## Pricing model (`instant_quote_pricing`)
One row per rule, keyed `(service, item_key)`. `pricing_type` ∈ `base_range · per_opening · per_door · per_drawer · flat · multiplier · custom_quote`.
`applies_when` is an optional JSON rule `{"answer_key":"wood","equals":"oak"}` the calculator checks against the visitor's answers.
Seeded with the site's standard ranges (painting $4,900–9,900, refacing $10,000–29,000, remodel $15,000–50,000+, refinishing = custom quote)
plus storage add-on prices from `items_catalog`. **Edit prices in Supabase, not in code.** A `calculate-quote` function (card 6) will read these rows.

## Rules carried over from the main site
Fonts preloaded + inline `@font-face` (no Google css2 link); GA4 `G-10ECEWKJXD` injected after window `load`; no Meta pixel yet
(add the deferred `loadMarketing()` pattern from the main site if you want conversion tracking — never Facebook's stock snippet).
Never deploy from an agent — Raymond reviews and pushes.
