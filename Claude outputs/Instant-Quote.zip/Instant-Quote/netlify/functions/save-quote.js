// POST /api/save-quote
// Upserts an in-progress instant quote (answers so far) into HCD Books → public.instant_quotes.
// Called after every answer, so it must be idempotent on quote_id.
const { createClient } = require('@supabase/supabase-js');

const ALLOWED_STATUS = ['in_progress', 'priced', 'submitted', 'abandoned'];

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers, body: '' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };

  let body;
  try { body = JSON.parse(event.body || '{}'); } catch (e) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid JSON' }) };
  }

  const quoteId = String(body.quote_id || '');
  if (!/^[0-9a-f-]{36}$/i.test(quoteId)) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'quote_id must be a UUID' }) };
  }
  const answers = (body.answers && typeof body.answers === 'object') ? body.answers : {};
  const status = ALLOWED_STATUS.includes(body.status) ? body.status : 'in_progress';

  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: 'Supabase not configured' }) };
  }
  const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

  const row = {
    id: quoteId,
    status,
    service: answers.service || null,
    current_step: body.current_step || null,
    answers,
    source: body.source || 'instant-quote',
    page_url: body.page_url || null,
    referrer: body.referrer || null,
    user_agent: event.headers['user-agent'] || null,
    started_at: body.started_at || new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  const { error } = await supabase.from('instant_quotes').upsert(row, { onConflict: 'id' });
  if (error) {
    console.error('save-quote upsert failed', error);
    return { statusCode: 500, headers, body: JSON.stringify({ error: 'Save failed' }) };
  }
  return { statusCode: 200, headers, body: JSON.stringify({ ok: true, quote_id: quoteId }) };
};
