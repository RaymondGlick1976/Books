-- Instant Quote — tables in the HCD Books Supabase project (byozvlgtbwiohyrfvxii)
-- Applied 2026-11-02. Additive only; nothing existing is touched.

-- ---------------------------------------------------------------
-- 1. Every instant-quote session (saved after each answer)
-- ---------------------------------------------------------------
create table if not exists public.instant_quotes (
  id            uuid primary key,                       -- generated in the browser, upserted on every step
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  started_at    timestamptz,
  status        text not null default 'in_progress'
                check (status in ('in_progress','priced','submitted','abandoned')),
  service       text,                                   -- painting | refacing | refinishing | remodel | island | storage | unsure
  current_step  text,                                   -- card id the visitor is on
  answers       jsonb not null default '{}'::jsonb,     -- every card's answer, keyed by card id
  estimate_low  numeric(10,2),
  estimate_high numeric(10,2),
  estimate_breakdown jsonb,                             -- how the number was built (for the admin + the visitor)
  -- contact (collected on the final card)
  name          text,
  email         text,
  phone         text,
  city          text,
  zip           text,
  -- attribution
  source        text default 'instant-quote',
  page_url      text,
  referrer      text,
  user_agent    text,
  -- link into HCD Books once a human follows up
  customer_id   uuid references public.customers(id) on delete set null,
  job_id        uuid references public.jobs(id) on delete set null
);
create index if not exists instant_quotes_status_idx  on public.instant_quotes (status, updated_at desc);
create index if not exists instant_quotes_service_idx on public.instant_quotes (service);
create index if not exists instant_quotes_email_idx   on public.instant_quotes (lower(email));

alter table public.instant_quotes enable row level security;
-- No policies on purpose: only the service-role key (Netlify function) reads/writes.

-- ---------------------------------------------------------------
-- 2. Consumer-facing pricing rules the calculator reads
--    (separate from items_catalog / pricing_attributes, which are internal cost build-ups)
-- ---------------------------------------------------------------
create table if not exists public.instant_quote_pricing (
  id            uuid primary key default gen_random_uuid(),
  service       text not null,                          -- matches instant_quotes.service
  item_key      text not null,                          -- e.g. base_range, oak_surcharge, per_door
  label         text not null,
  pricing_type  text not null
                check (pricing_type in ('base_range','per_opening','per_door','per_drawer','flat','multiplier','custom_quote')),
  low           numeric(10,2),                          -- null for custom_quote
  high          numeric(10,2),
  multiplier    numeric(6,3),                           -- for pricing_type = 'multiplier'
  applies_when  jsonb,                                  -- optional rule: {"answer_key":"wood","equals":"oak"}
  notes         text,
  is_active     boolean not null default true,
  sort_order    integer not null default 0,
  updated_at    timestamptz not null default now(),
  unique (service, item_key)
);
alter table public.instant_quote_pricing enable row level security;
-- Read-only for the public web (anon) so the page can show ranges; writes via service role only.
create policy "instant_quote_pricing_public_read" on public.instant_quote_pricing
  for select using (is_active);

-- ---------------------------------------------------------------
-- 3. Seed — the site's settled standard ranges (CLAUDE.md, June 2026)
--    + catalog default prices for storage add-ons. Edit in HCD Books, not here.
-- ---------------------------------------------------------------
insert into public.instant_quote_pricing (service, item_key, label, pricing_type, low, high, applies_when, notes, sort_order) values
  ('painting',    'base_range',     'Cabinet painting — full kitchen',              'base_range',   4900,  9900,  null, 'Typical $5,500–8,000', 1),
  ('painting',    'typical_range',  'Cabinet painting — typical project',           'base_range',   5500,  8000,  null, 'Shown as "most kitchens land here"', 2),
  ('painting',    'oak_surcharge',  'Oak grain-fill surcharge',                     'flat',         500,   1500,  '{"answer_key":"wood","equals":"oak"}', 'vs. maple/birch', 3),
  ('painting',    'two_tone',       'Two-tone (island/lowers a second color)',      'base_range',   5500,  11000, '{"answer_key":"two_tone","equals":"yes"}', 'Replaces base range when chosen', 4),
  ('refacing',    'base_range',     'Cabinet refacing — full kitchen',              'base_range',   10000, 29000, null, 'Typical $12–22k', 1),
  ('refacing',    'typical_range',  'Cabinet refacing — typical project',           'base_range',   12000, 22000, null, null, 2),
  ('refinishing', 'base_range',     'Cabinet refinishing',                          'custom_quote', null,  null,  null, 'Custom quote only — no dollar range on the site', 1),
  ('remodel',     'base_range',     'Kitchen remodel — partial or full',            'base_range',   15000, 50000, null, '"$50,000+" — show high as a plus', 1),
  ('remodel',     'full_range',     'Full remodel / replacement only',              'base_range',   35000, 50000, '{"answer_key":"remodel_scope","equals":"full"}', '"$35,000+"', 2),
  ('island',      'base_range',     'Custom kitchen island',                        'custom_quote', null,  null,  null, 'TODO Raymond: set a range or keep custom', 1),
  ('storage',     'rollout_base',   'Roll-out drawers — base cabinet set',          'flat',         150,   150,   null, 'items_catalog default', 1),
  ('storage',     'rollout_pantry', 'Roll-out drawers — pantry set',                'flat',         200,   200,   null, 'items_catalog default', 2),
  ('storage',     'trash_single',   'Trash pull-out — single',                      'flat',         425,   425,   null, 'items_catalog default', 3),
  ('storage',     'trash_double',   'Trash pull-out — double',                      'flat',         450,   450,   null, 'items_catalog default', 4)
on conflict (service, item_key) do nothing;
