// Instant Quote — runtime config (public values only; secrets live in Netlify env vars)
window.IQ_CONFIG = {
  // Netlify function on THIS site that saves answers + returns pricing.
  // /api/* is redirected to /.netlify/functions/* in netlify.toml
  apiBase: '/api',
  // Where "Book a free consultation" sends people at the end
  bookingUrl: 'https://www.homesteadcabinetdesign.com/free-consultation/',
  // Total steps shown in the progress bar (update as cards are added)
  totalSteps: 6,
  // sessionStorage key for in-progress answers
  storageKey: 'hcd_instant_quote_v1'
};
