// Instant Quote — card engine
// Renders IQ_CARDS one at a time, keeps answers in sessionStorage, and
// autosaves each step to the save-quote Netlify function (Supabase: instant_quotes).
(function () {
  'use strict';
  var CFG = window.IQ_CONFIG, CARDS = window.IQ_CARDS, ICONS = window.IQ_ICONS;
  var cardEl = document.getElementById('card');
  var fillEl = document.getElementById('progress-fill');
  var labelEl = document.getElementById('progress-label');
  var topicEl = document.getElementById('progress-topic');
  document.getElementById('year').textContent = new Date().getFullYear();

  // ---------- state ----------
  var state = load() || { quoteId: uuid(), answers: {}, history: [], startedAt: new Date().toISOString() };
  var currentIdx = state.history.length ? indexOf(state.history[state.history.length - 1]) : 0;
  if (currentIdx < 0) currentIdx = 0;

  function load() {
    try { var raw = sessionStorage.getItem(CFG.storageKey); return raw ? JSON.parse(raw) : null; } catch (e) { return null; }
  }
  function persist() {
    try { sessionStorage.setItem(CFG.storageKey, JSON.stringify(state)); } catch (e) {}
  }
  function uuid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
  }
  function indexOf(id) { for (var i = 0; i < CARDS.length; i++) if (CARDS[i].id === id) return i; return -1; }

  // ---------- autosave to Supabase (via Netlify function) ----------
  var saveTimer = null;
  function autosave(status) {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      var note = cardEl.querySelector('.save-state');
      if (note) note.textContent = 'Saving…';
      fetch(CFG.apiBase + '/save-quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          quote_id: state.quoteId,
          status: status || 'in_progress',
          current_step: CARDS[currentIdx] ? CARDS[currentIdx].id : null,
          answers: state.answers,
          started_at: state.startedAt,
          source: 'instant-quote',
          page_url: location.href,
          referrer: document.referrer || null
        })
      }).then(function (r) { return r.ok ? r.json() : Promise.reject(r.status); })
        .then(function () { if (note) note.textContent = 'Progress saved'; })
        .catch(function () { if (note) note.textContent = ''; /* silent: local copy still in sessionStorage */ });
    }, 400);
  }

  // ---------- rendering ----------
  function setProgress(idx, card) {
    var step = idx + 1;
    labelEl.textContent = 'Step ' + step + ' of ' + CFG.totalSteps;
    topicEl.textContent = card.topic || '';
    fillEl.style.width = Math.max(6, Math.round((idx / CFG.totalSteps) * 100)) + '%';
  }

  function render(idx) {
    var card = CARDS[idx];
    if (!card) return renderComingSoon();
    currentIdx = idx;
    setProgress(idx, card);
    var answer = state.answers[card.id];
    var html = '<h2 class="card-q">' + esc(card.question) + '</h2>';
    if (card.help) html += '<p class="card-help">' + esc(card.help) + '</p>';

    if (card.type === 'single') {
      html += '<div class="choices" role="radiogroup" aria-label="' + esc(card.question) + '">';
      card.options.forEach(function (o) {
        var on = answer === o.value;
        html += '<button type="button" class="choice" role="radio" aria-checked="' + on + '" data-value="' + esc(o.value) + '">' +
          '<span class="choice-icon">' + (ICONS[o.icon] || '') + '</span>' +
          '<span class="choice-body"><span class="choice-title">' + esc(o.title) + '</span>' +
          (o.desc ? '<span class="choice-desc">' + esc(o.desc) + '</span>' : '') + '</span>' +
          '<span class="choice-check" aria-hidden="true"></span></button>';
      });
      html += '</div>';
    } else if (card.type === 'select') {
      html += '<select class="iq-select" aria-label="' + esc(card.question) + '"><option value="">Choose one…</option>';
      card.options.forEach(function (o) {
        html += '<option value="' + esc(o.value) + '"' + (answer === o.value ? ' selected' : '') + '>' + esc(o.title) + '</option>';
      });
      html += '</select>';
    }

    html += '<div class="card-actions">' +
      '<button type="button" class="btn btn-ghost" id="btn-back"' + (idx === 0 ? ' hidden' : '') + '>&larr; Back</button>' +
      '<span class="save-state"></span>' +
      '<button type="button" class="btn btn-primary" id="btn-next"' + (card.required && !answer ? ' disabled' : '') + '>Continue &rarr;</button>' +
      '</div>' +
      '<p class="card-note"><svg viewBox="0 0 24 24"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>Your answers are private. No account or phone number needed to see your estimate.</p>';

    cardEl.innerHTML = html;
    cardEl.classList.remove('card'); void cardEl.offsetWidth; cardEl.classList.add('card'); // replay animation

    // wire up
    var choices = cardEl.querySelectorAll('.choice');
    Array.prototype.forEach.call(choices, function (btn) {
      btn.addEventListener('click', function () {
        Array.prototype.forEach.call(choices, function (b) { b.setAttribute('aria-checked', 'false'); });
        btn.setAttribute('aria-checked', 'true');
        setAnswer(card, btn.getAttribute('data-value'));
      });
    });
    var sel = cardEl.querySelector('.iq-select');
    if (sel) sel.addEventListener('change', function () { setAnswer(card, sel.value); });

    document.getElementById('btn-next').addEventListener('click', function () { advance(card); });
    var back = document.getElementById('btn-back');
    if (back) back.addEventListener('click', goBack);
  }

  function setAnswer(card, value) {
    state.answers[card.id] = value;
    persist();
    document.getElementById('btn-next').disabled = card.required && !value;
    if (window.gtag) gtag('event', 'iq_answer', { card: card.id, value: value });
    autosave();
  }

  function advance(card) {
    if (card.required && !state.answers[card.id]) return;
    if (state.history[state.history.length - 1] !== card.id) state.history.push(card.id);
    persist();
    var nextId = typeof card.next === 'function' ? card.next(state.answers) : card.next;
    var nextIdx = nextId ? indexOf(nextId) : currentIdx + 1;
    if (nextIdx >= 0 && nextIdx < CARDS.length) {
      render(nextIdx);
      window.scrollTo({ top: document.getElementById('wizard').offsetTop - 70, behavior: 'smooth' });
    } else {
      renderComingSoon();
    }
  }

  function goBack() {
    state.history.pop();
    var prevId = state.history[state.history.length - 1];
    persist();
    render(prevId ? indexOf(prevId) : 0);
  }

  // Placeholder shown until the next card exists
  function renderComingSoon() {
    var svc = state.answers.service;
    var label = svc && CARDS[0].options.filter(function (o) { return o.value === svc; })[0];
    labelEl.textContent = 'Step 2 of ' + CFG.totalSteps;
    topicEl.textContent = 'Coming soon';
    fillEl.style.width = Math.round((1 / CFG.totalSteps) * 100) + '%';
    cardEl.innerHTML =
      '<h2 class="card-q">Thanks — we\'re still wiring up the next questions.</h2>' +
      '<p class="card-help">You chose <strong>' + esc(label ? label.title : '—') + '</strong>. ' +
      'The rest of the instant quote is under construction. In the meantime you can book a free consultation and we\'ll price it in person.</p>' +
      '<div class="card-actions">' +
        '<button type="button" class="btn btn-ghost" id="btn-back">&larr; Back</button>' +
        '<a class="btn btn-primary" href="' + esc(CFG.bookingUrl) + '">Book a free consultation &rarr;</a>' +
      '</div>';
    document.getElementById('btn-back').addEventListener('click', function () { render(0); });
  }

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  render(currentIdx);
})();
