// Instant Quote — card definitions
// Each card: { id, topic, question, help, type, options?, next(answers) }
// Cards are added one at a time. The engine (quote.js) renders whatever is in IQ_CARDS.
//
// `service` keys must match instant_quote_pricing.service in Supabase (HCD Books project).

window.IQ_CARDS = [
  {
    id: 'service',
    topic: 'Your project',
    question: 'What would you like done to your cabinets?',
    help: 'Pick the one that fits best — you can change it later.',
    type: 'single',          // single-select tiles (swap to 'select' for a dropdown)
    required: true,
    options: [
      {
        value: 'painting',
        title: 'Cabinet Painting',
        desc: 'Keep your doors, change the color. Spray-finished in our shop.',
        icon: 'brush'
      },
      {
        value: 'refacing',
        title: 'Cabinet Refacing',
        desc: 'New doors & drawer fronts, boxes re-skinned to match.',
        icon: 'door'
      },
      {
        value: 'refinishing',
        title: 'Cabinet Refinishing',
        desc: 'Renew the wood finish — same tone or darker, new clear coats.',
        icon: 'wood'
      },
      {
        value: 'remodel',
        title: 'New Cabinets / Kitchen Remodel',
        desc: 'Custom-built cabinetry, partial or full kitchen.',
        icon: 'kitchen'
      },
      {
        value: 'island',
        title: 'Kitchen Island',
        desc: 'A new custom island, with or without seating.',
        icon: 'island'
      },
      {
        value: 'storage',
        title: 'Storage & Hardware Upgrades',
        desc: 'Roll-outs, soft-close, trash pull-outs, lazy susans.',
        icon: 'drawer'
      },
      {
        value: 'unsure',
        title: "Not sure — help me choose",
        desc: "We'll ask about your cabinets and suggest the best fit.",
        icon: 'help'
      }
    ],
    next: function () { return null; }   // card 2 goes here
  }
];

// Simple inline icon set (stroke icons, inherit color)
window.IQ_ICONS = {
  brush:   '<svg viewBox="0 0 24 24"><path d="M4 20c2-.5 3.5-2 3.5-4.5a2.5 2.5 0 0 1 5 0c0 3-3.5 4.5-8.5 4.5z"/><path d="M11 14 20 5a1.5 1.5 0 0 0-2-2l-9 9"/></svg>',
  door:    '<svg viewBox="0 0 24 24"><rect x="5" y="3" width="14" height="18" rx="1.5"/><rect x="8" y="6" width="8" height="12" rx="1"/><circle cx="14.5" cy="12" r=".8"/></svg>',
  wood:    '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="1.5"/><path d="M3 10c4 0 4-2 8-2s4 2 10 2M3 15c5 0 5-2 9-2s4 2 9 2"/></svg>',
  kitchen: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="1.5"/><path d="M3 12h18M12 12v8M7.5 8h2M14.5 8h2"/></svg>',
  island:  '<svg viewBox="0 0 24 24"><rect x="4" y="9" width="16" height="9" rx="1.5"/><path d="M2 9h20M8 18v2M16 18v2M9 13h2M13 13h2"/></svg>',
  drawer:  '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="7" rx="1.5"/><rect x="3" y="13" width="18" height="7" rx="1.5"/><path d="M10 7.5h4M10 16.5h4"/></svg>',
  help:    '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 .9-1 1.7"/><circle cx="12" cy="17" r=".6"/></svg>'
};
